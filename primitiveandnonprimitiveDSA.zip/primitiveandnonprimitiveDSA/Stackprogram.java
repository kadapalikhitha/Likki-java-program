package primitiveandnonprimitiveDSA;

public class Stackprogram {
	
	private int maxSize;
	private int [] stackArray;
	private int top;
	
	public Stackprogram(int size)
	{
		maxSize = size;
		stackArray = new int [maxSize];
		top = -1;
	}
	public void push(int value)
	{
		if (top >= maxSize - 1)
		{
			System.out.println("Stack Overflow!");
			return;
		}
		stackArray[++top] = value;
		System.out.println("Pushed: " + value);
	}
	
	public int pop() 
	{
		if (isEmpty())
		{
			System.out.println("Stack Underflow!");
			return -1;
		}
		return stackArray[top--];
	}
	
	public int peek()
	{
		if (isEmpty())
		{
			System.out.println("Stack is Empty!");
			return -1;
		}
		return stackArray[top];
	}
	
	public boolean isEmpty()
	{
		return top == -1;
	}
	
	public void display()
	{
		System.out.println("Stack: ");
		for (int i = 0; i <= top; i++)
		{
			System.out.println(stackArray[i] + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Stackprogram stack = new Stackprogram(5);
		
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.display();
		
		System.out.println("Peek: " + stack.peek());
		
		System.out.println("popped: " + stack.pop());
		stack.display();
		
		System.out.println("Is Emoty? " + stack.isEmpty());// TODO Auto-generated method stub

	}

}