package javaexcerciseprogram;

public class StringStandard {
	

		public static void main(String[] args) {
			
					 
					   String s="Sachin";
					   System.out.println(s.startsWith("Sa"));//true
					   System.out.println(s.endsWith("n"));//true
					 }
			}

