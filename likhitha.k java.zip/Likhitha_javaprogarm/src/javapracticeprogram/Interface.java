package javapracticeprogram;

// Define an interface
interface Printable {
    void print();
}

// Implement the interface
class Document implements Printable {
    @Override
    public void print() {
        System.out.println("Printing a document...");
    }
}

class Photo implements Printable {
    @Override
    public void print() {
        System.out.println("Printing a photo...");
    }
}

public class Interface {
    public static void main(String[] args) {
        Printable document = new Document();
        Printable photo = new Photo();

        document.print();
        photo.print();
    }
}
