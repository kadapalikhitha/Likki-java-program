package javapracticeprogram;

public class arithmeticOperation 
{
	public int sum(int a, int b) 
	{
		int c = a + b;
		return c;
	}

}
