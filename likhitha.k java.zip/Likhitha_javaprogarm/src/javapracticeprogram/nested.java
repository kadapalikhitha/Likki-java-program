package javapracticeprogram;

public class nested {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        int x = 10;
		        int y = 5;

		        if (x > 5) {
		            if (y > 2) {
		                System.out.println("x is greater than 5 and y is greater than 2");
		            } else {
		                System.out.println("x is greater than 5 but y is not greater than 2");
		            }
		        } else {
		            System.out.println("x is not greater than 5");
		        }
		    }
		}