package javapracticeprogram;
public class Static {

    // Static variable
    static int count = 0;

    // Static method
    static void displayCount() {
        System.out.println("Count is: " + count);
    }

    public static void main(String[] args) {
        // Access static variable without creating object
        count = 5;

        // Call static method without creating object
        displayCount();
    }
}