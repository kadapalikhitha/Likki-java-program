package javapracticeprogram;

import java.util.Scanner;

public class ifelse {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your grade (A, B, C, D, or F): ");
        String grade = scanner.next();

        if (grade.equalsIgnoreCase("A")) {
            System.out.println("Excellent!");
        } else if (grade.equalsIgnoreCase("B")) {
            System.out.println("Good job!");
        } else if (grade.equalsIgnoreCase("C")) {
            System.out.println("Fair.");
        } else if (grade.equalsIgnoreCase("D")) {
            System.out.println("Needs improvement.");
        } else if (grade.equalsIgnoreCase("F")) {
            System.out.println("Failed.");
        } else {
            System.out.println("Invalid grade.");
        }

        scanner.close();
    }
}
