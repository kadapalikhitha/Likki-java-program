package javapracticeprogram;

public class Variablevalue {
	public static void main(String[] args) {
		int x =10;
		String name = "bunny";
		System.out.println("value of x: "+ x);
		System.out.println("Name:" + name);
	}

}
