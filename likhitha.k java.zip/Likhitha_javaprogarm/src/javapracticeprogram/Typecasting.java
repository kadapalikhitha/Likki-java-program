package javapracticeprogram;

public class Typecasting {
	public class typrcasting {
		public static void main(String[] args) {
			double a=45.5;
			byte b;
			b=(byte)a;
			System.out.println(a);
			System.out.println(b);
		}

	}

}
