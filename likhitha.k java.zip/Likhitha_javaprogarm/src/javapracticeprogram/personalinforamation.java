package javapracticeprogram;

public class personalinforamation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // Personal details
        String name = "likki";
        int age = 21;
        char gender = 'F';
        String phone = "9876543210";
        String address = "Hyderabad, India";

        // Displaying the personal information
        System.out.println("----- Personal Information -----");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Phone: " + phone);
        System.out.println("Address: " + address);
    }
}