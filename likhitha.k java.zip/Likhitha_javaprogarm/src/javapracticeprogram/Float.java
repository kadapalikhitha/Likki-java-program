package javapracticeprogram;

public class Float {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        float num1 = 10.5f;
		        float num2 = 2.5f;
		        float sum = num1 + num2;
		        System.out.println("The sum is: " + sum);
	}

}
