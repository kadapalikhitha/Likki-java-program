package javapracticeprogram;

public class arthmeticoperation1 {
		public int sum(int a, int b) 
		{
			int c = a + b;
			return c;
		}

	}



