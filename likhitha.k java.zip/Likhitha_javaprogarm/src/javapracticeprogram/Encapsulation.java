package javapracticeprogram;

//Encapsulation example
class Person {
// Private fields (hidden from outside)
private String name;
private int age;

// Public setter for name
public void setName(String name) {
   this.name = name;
}

// Public getter for name
public String getName() {
   return name;
}

// Public setter for age
public void setAge(int age) {
   if (age > 0) {  // simple validation
       this.age = age;
   }
}

// Public getter for age
public int getAge() {
   return age;
}
}

public class Encapsulation {
public static void main(String[] args) {
   Person p = new Person();
   
   // Set values using setters
   p.setName("Radha");
   p.setAge(25);
   
   // Get values using getters
   System.out.println("Name: " + p.getName());
   System.out.println("Age: " + p.getAge());
}
}

