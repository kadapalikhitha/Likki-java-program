package javapracticeprogram;

public class Int {
	public static void main(String[] args) {
		int a=2134567;
		System.out.println(a);
	}

}
