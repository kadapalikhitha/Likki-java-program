package TreeandMap;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        
        // Create a HashMap
        Map<String, Integer> map = new HashMap<>();

        // Add elements
        map.put("Apple", 3);
        map.put("Banana", 5);
        map.put("Orange", 2);

        // Get value by key
        System.out.println("Apple count: " + map.get("Apple"));

        // Iterate through map entries
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Check if a key exists
        if (map.containsKey("Banana")) {
            System.out.println("Banana exists");
        }

        // Remove an element
        map.remove("Orange");

        // Print map size
        System.out.println("Size: " + map.size());
    }
}
