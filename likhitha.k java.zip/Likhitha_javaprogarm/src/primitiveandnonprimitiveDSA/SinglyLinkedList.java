package primitiveandnonprimitiveDSA;

//singly Linked List implementation in java
public class SinglyLinkedList {
// Node class representing each element in the list
	static class Node{
		int data;
		Node next;
		Node(int data) {
			this.data =data;
			this.next =null;
		}
	}
	// Head pointer to the first node
	Node head = null;
// Insert a new node at the end
	public void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
		} else {
			Node temp = head;
				// Traverse to the last node
			while (temp.next != null ) {
				temp = temp.next;
			}
			//Insert new node at the end
			temp.next = newNode;
		}
	}
	//Delete node by value
	public void delete(int value) {
		if (head == null) {
			System.out.println("List is empty!");
			return;
		}
		if (head.data == value) {
			head = head.next;//remove head
			return;
		}
		Node current = head;
		Node previous = null;
		//search  for the node to delete
		while (current != null && current.data != value) {
			previous = current;
			current = current.next;
		}
		//If not found
		if ( current == null) {
			System.out.println("value not found!");
			return;
		}
		//Remove node
		previous.next = current.next;
	}
	//search for a value in the list
	public boolean search(int key) {
		Node temp = head;
		while (temp != null) {
			if (temp.data == key) {
				return true;
			}
			temp = temp.next;
		}
		return false;
	}
		//Display the linked list
		public void dispaly() {
			if (head == null) {
				System.out.println(" List is empty.");
				return;
			}
			Node temp = head;
			System.out.println("Linked List: ");
			while (temp !=null) {
				System.out.println(temp.data + "  ");
				temp = temp.next;
			}
			System.out.println("NULL");
		}
		//Main method to test the Linked List
		public static void main(String[] args) {
			SinglyLinkedList list = new SinglyLinkedList();
			//Insert elements
			list.insert(10);
			list.insert(20);
			list.insert(30);
			list.insert(40);
			//Display list
			list.dispaly(); // 10  20  30  40  NULL
			//Search element
			System.out.println("searching 30: "+ list.search(30));
			//Delete element
			list.delete(20);
			list.dispaly(); // 10  20  30  40  NULL
			//Delete head
			list.delet(10);
			list.display(); // 30  40  NULL
			}
		private void display() {
			// TODO Auto-generated method stub
			
		}
		private void delet(int i) {
			// TODO Auto-generated method stub
			
		}
			
	}

