package primitiveandnonprimitiveDSA;


// Doubly Linked List in java
public class DoublyLinkedList {
	
	// Node class for DLL
	static class Node {
		int data;
		Node prev;
		Node next;
		
		Node(int data) {
			this.data = data;
		}
	}
	
	//Head and Tail references
	Node head = null;
	Node tail = null;
	
	// Insert at end
	public void insert(int data) {
		Node newNode = new Node(data) ;
		
		if (head == null) {
			head = tail = newNode; //First node
		} else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
		}
	}
	
	//Delete node by value
	public void delete(int value) {
		if (head == null) {
			System.out.println("List is empty!");
			return;
		}
		
		Node current = head;
		
		while (current != null && current.data != value) {
			current = current.next;
		}
		
		if (current == null) {
			System.out.println("value not found");
			return;
		}
		
		//Node is head
		if (current == head) {
			head = head.next;
			if (head != null) head.prev = null;
		}
		//Node is tail
		else if (current == tail) {
			tail = tail.prev;
			tail.next = null;
		}
		//Node is in between
		else {
			current.prev.next =current.next;
			current.next.prev = current.prev;
		}
	}
	
	//search for a value
	public boolean search(int key) {
		Node temp = head;
		while (temp != null) {
			if (temp.data == key) return true;
			temp = temp.next;
		}
		return false;
	}
	
	// Display forward
	public void displayForward() {
		Node temp = head;
		System.out.println("Forward: ");
		while (temp != null) {
			System.out.println(temp.data + "    ");
			temp = temp.next;
		}
		System.out.println("NULL");
	}
	
	//Display backward
	public void displayBackward() {
		Node temp = tail;
		System.out.println("Backward: ");
		while (temp != null) {
			System.out.println(temp.data + "  ");
			temp = temp.prev;
		}
		System.out.println("NULL");
	}
	
	// Main method for testing
	public static void main(String[] args) {
		DoublyLinkedList dll = new DoublyLinkedList();
		
		//Insert elements
		dll.insert(10);
		dll.insert(20);
		dll.insert(30);
		dll.insert(40);
		
		//Display forward and backward
		dll.displayForward(); // 10  20  30  40  NULL
		dll.displayForward(); // 40  30  20  10  NULL
		
		//Search
		System.out.println("search 30: " + dll.search(30));
		System.out.println("search 50: " + dll.search(50));
		
		// Delete
		dll.delete(20);
		dll.displayForward();     // 10  30  40  NULL
		
		dll.delete(10);
		dll.displayForward();    // 30  40  NULL
		
		dll.delete(40);
		dll.displayForward();   //30  NULL
	}
		
	}

