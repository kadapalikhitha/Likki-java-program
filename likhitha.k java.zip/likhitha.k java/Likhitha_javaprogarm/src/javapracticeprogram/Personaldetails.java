package javapracticeprogram;

public class Personaldetails {
    public static void main(String[] args) {
        String name = "John Doe";
        int age = 30;
        String address = "123 Main St";
        String phoneNumber = "123-456-7890";
        String email = "johndoe@example.com";

        System.out.println("Personal Details:");
        System.out.println("--------------------");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email: " + email);
    }
}