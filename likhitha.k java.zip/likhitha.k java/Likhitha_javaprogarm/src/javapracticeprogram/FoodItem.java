package javapracticeprogram;

interface FoodItem {

}
