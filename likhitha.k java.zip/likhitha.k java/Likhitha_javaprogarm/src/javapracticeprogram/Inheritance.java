package javapracticeprogram;
//Define a parent class
class Animal {
 void eat() {
     System.out.println("Eating...");
 }

 void sleep() {
     System.out.println("Sleeping...");
 }
}

//Define a child class that inherits from Animal
class Dog extends Animal {
 void bark() {
     System.out.println("Barking...");
 }
}

//Define another child class that inherits from Animal
class Cat extends Animal {
 void meow() {
     System.out.println("Meowing...");
 }
}

public class Inheritance {
 public static void main(String[] args) {
     Dog dog = new Dog();
     Cat cat = new Cat();

     System.out.println("Dog's actions:");
     dog.eat();
     dog.sleep();
     dog.bark();

     System.out.println("\nCat's actions:");
     cat.eat();
     cat.sleep();
     cat.meow();
 }
}