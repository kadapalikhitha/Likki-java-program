package javapracticeprogram;
public class ICICI {
    public static void main(String[] args) {
        System.out.println("ICICI Bank");
        System.out.println("-----------");
        System.out.println("Full Form: Industrial Credit and Investment Corporation of India");
        System.out.println("Services: Banking, Loans, Credit Cards, Insurance, etc.");
    }
}
