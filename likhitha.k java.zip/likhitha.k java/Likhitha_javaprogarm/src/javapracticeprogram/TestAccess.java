package javapracticeprogram;
class AccessModifierDemo {
    public String publicVar = "I am public";
    private String privateVar = "I am private";
    protected String protectedVar = "I am protected";
    String defaultVar = "I have default access";

    public void display() {
        System.out.println(publicVar);
        System.out.println(privateVar);
        System.out.println(protectedVar);
        System.out.println(defaultVar);
    }
}

public class TestAccess {
    public static void main(String[] args) {
        AccessModifierDemo obj = new AccessModifierDemo();

        // Accessing variables
        System.out.println(obj.publicVar);      // Accessible anywhere
        // System.out.println(obj.privateVar);  // Not accessible outside the class
        System.out.println(obj.protectedVar);   // Accessible within same package or subclass
        System.out.println(obj.defaultVar);     // Accessible within same package

        obj.display();  // Can access all variables inside the class
    }
}