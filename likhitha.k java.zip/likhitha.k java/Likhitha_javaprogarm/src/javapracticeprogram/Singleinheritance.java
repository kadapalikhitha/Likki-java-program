package javapracticeprogram;

public class Singleinheritance {
	class Animal {
	    void eat() {
	        System.out.println("The animal eats");
	    }
	}

	class Dog extends Animal {
	    void bark() {
	        System.out.println("The dog barks");
	    }
	}
}
