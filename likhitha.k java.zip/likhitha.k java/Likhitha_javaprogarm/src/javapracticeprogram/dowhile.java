package javapracticeprogram;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int i = 1;
		  do {
			  System.out.println("iteration" + i);
		 
			  i++;
		  }while (i <= 5);
	}
}
