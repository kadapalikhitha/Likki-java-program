package javapracticeprogram;

public class Short {
	public static void main(String[] args) {
		short a=32767;
		System.out.println(a);
	}

}
