package javapracticeprogram;

public class overriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class Animal {
		    void sound() {
		        System.out.println("The animal makes a sound");
		  
		    
		    }
		}


	}

}
