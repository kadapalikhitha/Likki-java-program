package javapracticeprogram;

public class Printstatment {
	    public static void main(String[] args) {
	        int age = 30;
	        String name = "likki";
	        System.out.printf("My name is %s and I am %d years old.", name, age);
	    }
	}

