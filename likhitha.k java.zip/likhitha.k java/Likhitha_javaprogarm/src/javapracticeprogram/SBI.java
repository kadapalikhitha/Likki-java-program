package javapracticeprogram;
public class SBI {
    public static void main(String[] args) {
        System.out.println("State Bank of India");
        System.out.println("---------------------");
        System.out.println("SBI");
    }
}
