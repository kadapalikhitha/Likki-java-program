package javapracticeprogram;

public class Char {
	public static void main(String[] args) {
			char a='k';
			System.out.println(a);
		}

	}
