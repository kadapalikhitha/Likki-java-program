package javapracticeprogram;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int i = 2;
		  while (i <= 10) {
			  System.out.println(i);
			  i += 2;
		  }

	}

}
