package javapracticeprogram;

public class dataconversation {
	 public static void main(String[] args) {
		 long a=45;
		 int b;
		 b=(int)a;
		 System.out.println(a);
		 System.out.println(b);
	 }

}
