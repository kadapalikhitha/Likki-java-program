package javapracticeprogram;
import java.util.Scanner;

public class Scannerprogram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // Create scanner object
        
        System.out.print("name: ");
        String name = scanner.nextLine();          // Read user input
        
        System.out.println("Hello, " + name + "!");  // Print output
        
        scanner.close();                            // Close the scanner
    }
}