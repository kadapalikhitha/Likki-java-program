package javapracticeprogram;

public class bankp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class BankP {			//Main Class file <Features of Bank>
			float getRateOfInterest()   {
				return 0;              
			}
		}


	}

}
