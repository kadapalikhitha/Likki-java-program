package javapracticeprogram;

public class overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        System.out.println(add(10, 20));
		        System.out.println(add(10, 20, 30));
		        System.out.println(add(10.5, 20.7));
		    }

		    public static int add(int num1, int num2) {
		        return num1 + num2;
		    }

		    public static int add(int num1, int num2, int num3) {
		        return num1 + num2 + num3;
		    }

		    public static double add(double num1, double num2) {
		        return num1 + num2;
	}

}
