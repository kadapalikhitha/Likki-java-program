package javaexcerciseprogram;

import javapracticeprogram.arthmeticoperation1;

public class callingarthmetic {

	public static void main(String[] args) {
		arthmeticoperation1 obj=new arthmeticoperation1();
		System.out.println(obj.sum(6, 6));
		// TODO Auto-generated method stub

	}

}
