 package Java;

abstract class Bikeabstract
{
	   abstract void run();
	 }

	 

