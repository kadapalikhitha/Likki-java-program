package Java;

public class Encapsulation2 
{

	public static void main(String[] args) 
	{
		Encapsulation1 obj = new Encapsulation1();
	    
		obj.setName("Vivek");
	    System.out.print("Name : " + obj.getName());  //vivek
	}

}
