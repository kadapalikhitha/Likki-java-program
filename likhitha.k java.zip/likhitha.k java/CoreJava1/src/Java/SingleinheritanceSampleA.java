package Java;

public class SingleinheritanceSampleA {
	public void methodA()
	   {
	     System.out.println("Base class");
	   }
}
