package Java;
public class PersonalInformation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner("System.in");
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over
        System.out.print("Enter your address: ");
        String address = scanner.nextLine();
        System.out.print("Enter your phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        Person person = new Person("name, age, address, phoneNumber, email");
        System.out.println("\nYour Personal Information:");
        person.displayInfo();
    }
}

